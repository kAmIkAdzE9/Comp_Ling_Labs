﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_1
{
    public partial class Form2 : Form
    {
        List<Word> words;
        public Form2(List<Word> words)
        {
            InitializeComponent();
            this.words = words;

            chart1.Series[0].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            dataGridView1.Columns.Add("Number", "№");
            dataGridView1.Columns.Add("Word", "Word");
            dataGridView1.Columns.Add("Rate", "Rate");
            dataGridView1.Columns.Add("Rank", "Rank");
            printInfo();
        }

        private void printInfo()
        {          
            int counter = 0;
            foreach(Word word in this.words)
            {
                dataGridView1.Rows.Add(counter, word.getName(), word.getRate(), word.getRank());
                chart1.Series[0].Points.AddXY(word.getRank(), word.getRate());
                counter++;    
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();
            dataGridView1.Columns.Add("Number", "№");
            dataGridView1.Columns.Add("Word", "Word");
            dataGridView1.Columns.Add("Rate", "Rate");
            dataGridView1.Columns.Add("Rank", "Rank");
            int counter = 0;
            foreach (Word word in this.words)
            {
                word.setName(new string (word.getName().ToCharArray().Reverse().ToArray()));
                dataGridView1.Rows.Add(counter, word.getName(), word.getRate(), word.getRank());
                counter++;
            }
        }
    }
}
