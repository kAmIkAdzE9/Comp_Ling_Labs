﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_1
{
    public partial class Form1 : Form
    {
        private static char[] delimeterChars = {' ', '\n', ',', '.', ';', '!', '?', '-', ':', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '=', '>', '<', '+', '*', '/', '(', ')', '{', '}', '[', ']', '`', '–', '&', '^', '%', '#', '№', '@', '$', '\\', '\'', '\"', '—' };

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
        }   

        private void button1_Click(object sender, EventArgs e)
        {            
            Form2 form2 = new Form2(convertData(textBox1.Text));
            form2.Show();
        }

        private List<Word> convertData(string input)
        {
            List<Word> words = new List<Word>();
            bool flag = true;
            foreach (string tmp in input.Split(delimeterChars, System.StringSplitOptions.RemoveEmptyEntries))
            {
                foreach (Word word in words)
                {
                    if (word.getName() == tmp)
                    {
                        word.setRate(word.getRate() + 1);
                        flag = false;
                    }
                }

                if (flag)
                {
                    words.Add(new Word(tmp, 1, 1));
                }

                flag = true;
            }

            return calculateListElementsRank(sortListByRate(words));
        }
        
        private List<Word> sortListByRate (List<Word> words)
        {
            return words.OrderByDescending(x => x.getRate()).ToList();
        }

        private List<Word> calculateListElementsRank (List<Word> words)
        {
            int counter = 1;
            int rate = words[0].getRate();

            for (int i = 1; i < words.Count(); i++)
            {
                if (words[i].getRate() != rate)
                {
                    counter += 1;
                }
                rate = words[i].getRate();
                words[i].setRank(counter);
            }
            return words;
        }
    }
}
