﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1
{
    public class Word
    {
        private string name;
        private int rate;
        private int rank;

        public Word()
        {

        }

        public Word (string name, int rate, int rank)
        {
            this.name = name;
            this.rate = rate;
            this.rank = rank;
        }

        public void setName (string name)
        {
            this.name = name;
        }

        public string getName ()
        {
            return this.name;
        }

        public void setRate(int rate)
        {
            this.rate = rate;
        }

        public int getRate()
        {
            return this.rate;
        }

        public void setRank(int rank)
        {
            this.rank = rank;
        }

        public int getRank()
        {
            return this.rank;
        }
    }
}
